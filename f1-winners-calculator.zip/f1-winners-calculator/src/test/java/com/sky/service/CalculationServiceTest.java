package com.sky.service;

import com.sky.model.Driver;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.assertEquals;

public class CalculationServiceTest {

    private CalculationService calculationService;

    @Before
    public void setUp() {
        calculationService = new CalculationService();
    }

    @Test
    public void processDrivers() {
        assertEquals(buildExpectedResult(), calculationService.processDrivers(buildInputDrivers()));
    }

    private List<Driver> buildInputDrivers() {
        List<Driver> drivers = new ArrayList<>();
        drivers.add(new Driver("Alonzo", 4.32));
        drivers.add(new Driver("Verstrappen", 4.75));
        drivers.add(new Driver("Alonzo", 4.88));
        drivers.add(new Driver("Hamilton", 4.65));
        drivers.add(new Driver("Alonzo", 4.38));
        drivers.add(new Driver("Verstrappen", 4.55));
        drivers.add(new Driver("Hamilton", 4.61));
        drivers.add(new Driver("Hamilton", 4.43));
        drivers.add(new Driver("Verstrappen", 4.59));
        return drivers;
    }

    private List<Driver> buildExpectedResult() {
        List<Driver> drivers = new ArrayList<>();

        Driver alonzo = new Driver("Alonzo", 4.32);
        alonzo.setLapCount(3);
        alonzo.setSumLapTime(13.579999999999998);
        alonzo.setAverageLapTime(4.526666666666666);

        Driver hamilton = new Driver("Hamilton", 4.65);
        hamilton.setLapCount(3);
        hamilton.setSumLapTime(13.690000000000001);
        hamilton.setAverageLapTime(4.5633333333333335);

        Driver verstrappen = new Driver("Verstrappen", 4.75);
        verstrappen.setLapCount(3);
        verstrappen.setSumLapTime(13.89);
        verstrappen.setAverageLapTime(4.63);

        Collections.addAll(drivers, alonzo, hamilton, verstrappen);
        return drivers;
    }
}