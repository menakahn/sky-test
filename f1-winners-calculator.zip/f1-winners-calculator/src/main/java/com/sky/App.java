package com.sky;

import com.sky.config.AppConfig;
import com.sky.config.JobConfig;
import com.sky.service.CalculationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

/**
 * @author Menaka HN
 * @apiNote Represents the main class, with which we can start this application
 */
public class App {

    private static final Logger LOGGER = LoggerFactory.getLogger(App.class);

    public static void main(String[] args) throws Exception {
        final AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
        context.register(JobConfig.class);
        context.register(AppConfig.class);
        context.register(CalculationService.class);
        context.refresh();

        final JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
        final Job job = (Job) context.getBean("job");
        final JobExecution execution = jobLauncher.run(job, new JobParametersBuilder().toJobParameters());
        LOGGER.info("Job Status : {}", execution.getStatus());
        LOGGER.info("Job succeeded");
    }
}
