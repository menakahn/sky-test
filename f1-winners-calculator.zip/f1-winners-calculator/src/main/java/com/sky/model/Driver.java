package com.sky.model;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Objects;

/**
 * @author Menaka HN
 * @apiNote Represents Driver model object
 */

@Component
public class Driver implements Serializable {

    private static final long serialVersionUID = 1L;

    private String name;
    private double currentLapTime;
    private int lapCount;
    private double sumLapTime;
    private double averageLapTime;

    public Driver(String name, double currentLapTime) {
        this.name = name;
        this.currentLapTime = currentLapTime;
        this.sumLapTime = currentLapTime;
        this.lapCount = 1;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getCurrentLapTime() {
        return currentLapTime;
    }

    public void setCurrentLapTime(double currentLapTime) {
        this.currentLapTime = currentLapTime;
    }

    public int getLapCount() {
        return lapCount;
    }

    public void setLapCount(int lapCount) {
        this.lapCount = lapCount;
    }

    public double getSumLapTime() {
        return sumLapTime;
    }

    public void setSumLapTime(double sumLapTime) {
        this.sumLapTime = sumLapTime;
    }

    public double getAverageLapTime() {
        return averageLapTime;
    }

    public void setAverageLapTime(double averageLapTime) {
        this.averageLapTime = averageLapTime;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Driver driver = (Driver) o;
        return Double.compare(driver.currentLapTime, currentLapTime) == 0 &&
                lapCount == driver.lapCount &&
                Double.compare(driver.sumLapTime, sumLapTime) == 0 &&
                Double.compare(driver.averageLapTime, averageLapTime) == 0 &&
                Objects.equals(name, driver.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, currentLapTime, lapCount, sumLapTime, averageLapTime);
    }

    @Override
    public String toString() {
        return "Driver{" +
                "name='" + name + '\'' +
                ", currentLapTime=" + currentLapTime +
                ", lapCount=" + lapCount +
                ", sumLapTime=" + sumLapTime +
                ", averageLapTime=" + averageLapTime +
                '}';
    }
}