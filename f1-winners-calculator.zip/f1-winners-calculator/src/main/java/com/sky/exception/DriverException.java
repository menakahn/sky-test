package com.sky.exception;

/**
 * @author Menaka HN
 * @apiNote Represents custom exception
 */
public class DriverException extends RuntimeException {

    public DriverException(String message, Throwable throwable) {
        super(message, throwable);
    }
}
