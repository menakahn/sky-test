package com.sky.tasklet;

import com.sky.model.Driver;
import com.sky.utils.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Menaka HN
 * @apiNote Represents Drivers Reader which helps in reading the input CSV
 */
public class DriversReader implements Tasklet, StepExecutionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(DriversReader.class);

    private List<Driver> drivers;
    private FileUtils fileUtils;
    private String inputFile;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        drivers = new ArrayList<>();
        fileUtils = new FileUtils(inputFile);
        LOGGER.debug("Drivers Reader initialized.");
    }

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) {
        Driver driver = fileUtils.readDriver();
        while (driver != null) {
            drivers.add(driver);
            LOGGER.debug("Read Driver: " + driver.toString());
            driver = fileUtils.readDriver();
        }
        return RepeatStatus.FINISHED;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        fileUtils.closeReader();
        stepExecution.getJobExecution().getExecutionContext().put("Drivers", this.drivers);
        LOGGER.debug("Drivers Reader ended.");
        return ExitStatus.COMPLETED;
    }

    @Value("${input.file:input/input.csv}")
    public void setInputFile(String inputFile) {
        this.inputFile = inputFile;
    }
}