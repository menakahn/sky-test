package com.sky.tasklet;

import com.sky.model.Driver;
import com.sky.service.CalculationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @author Menaka HN
 * @apiNote Represents Drivers Processor which performs the necessary calculations
 */
public class DriversProcessor implements Tasklet, StepExecutionListener {

    private final Logger logger = LoggerFactory.getLogger(DriversProcessor.class);
    private List<Driver> drivers;

    @Autowired
    private CalculationService calculationService;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        ExecutionContext executionContext = stepExecution.getJobExecution().getExecutionContext();
        this.drivers = (List<Driver>) executionContext.get("Drivers");
        logger.debug("Drivers Processor initialized.");
    }

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) {
        this.drivers = calculationService.processDrivers(drivers);
        return RepeatStatus.FINISHED;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        stepExecution.getJobExecution().getExecutionContext().put("ProcessedDrivers", this.drivers);
        logger.debug("Drivers Processor ended.");
        return ExitStatus.COMPLETED;
    }
}