package com.sky.tasklet;

import com.sky.model.Driver;
import com.sky.utils.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.item.ExecutionContext;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;

/**
 * @author Menaka HN
 * @apiNote Represents Drivers Writer which helps in writing to the output CSV
 */
public class DriversWriter implements Tasklet, StepExecutionListener {

    private static final Logger LOGGER = LoggerFactory.getLogger(DriversWriter.class);

    private List<Driver> drivers;
    private FileUtils fileUtils;
    private String outputFile;
    private int numberOfWinnersToDisplay;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        ExecutionContext executionContext = stepExecution.getJobExecution().getExecutionContext();
        this.drivers = (List<Driver>) executionContext.get("ProcessedDrivers");
        fileUtils = new FileUtils(outputFile);
        LOGGER.debug("Drivers Writer initialized.");
    }

    @Override
    public RepeatStatus execute(StepContribution stepContribution, ChunkContext chunkContext) {
        if(numberOfWinnersToDisplay > drivers.size()){
            numberOfWinnersToDisplay = drivers.size();
            LOGGER.error("Number of winners cannot be greater than the number of participant drivers. Hence displaying all the participants.");
        }
        for (Driver driver : drivers.subList(0, numberOfWinnersToDisplay)) {
            fileUtils.writeDriver(driver);
            LOGGER.debug("Wrote Driver " + driver.toString());
        }
        return RepeatStatus.FINISHED;
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        fileUtils.closeWriter();
        LOGGER.debug("Drivers Writer ended.");
        return ExitStatus.COMPLETED;
    }

    @Value("${output.file:output.csv}")
    public void setOutputFile(String outputFile) {
        this.outputFile = outputFile;
    }

    @Value("${number.of.winners.to.display:3}")
    public void setNumberOfWinnersToDisplay(int numberOfWinnersToDisplay) {
        this.numberOfWinnersToDisplay = numberOfWinnersToDisplay;
    }
}