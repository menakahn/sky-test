package com.sky.config;

import com.sky.tasklet.DriversProcessor;
import com.sky.tasklet.DriversReader;
import com.sky.tasklet.DriversWriter;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.support.SimpleJobLauncher;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.repository.support.MapJobRepositoryFactoryBean;
import org.springframework.batch.support.transaction.ResourcelessTransactionManager;
import org.springframework.batch.test.JobLauncherTestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

/**
 * @author Menaka HN
 * @apiNote This class describes different steps of the spring-batch-job.
 */

@Configuration
@EnableBatchProcessing
public class JobConfig {

    @Autowired
    private JobBuilderFactory jobs;

    @Autowired
    private StepBuilderFactory steps;

    @Bean
    public JobLauncherTestUtils jobLauncherTestUtils() {
        return new JobLauncherTestUtils();
    }

    @Bean
    public JobRepository jobRepository() throws Exception {
        MapJobRepositoryFactoryBean factory = new MapJobRepositoryFactoryBean();
        factory.setTransactionManager(transactionManager());
        return factory.getObject();
    }

    @Bean
    public PlatformTransactionManager transactionManager() {
        return new ResourcelessTransactionManager();
    }

    @Bean
    public JobLauncher jobLauncher() throws Exception {
        SimpleJobLauncher jobLauncher = new SimpleJobLauncher();
        jobLauncher.setJobRepository(jobRepository());
        return jobLauncher;
    }

    @Bean
    public DriversReader driversReader() {
        return new DriversReader();
    }

    @Bean
    public DriversProcessor driversProcessor() {
        return new DriversProcessor();
    }

    @Bean
    public DriversWriter driversWriter() {
        return new DriversWriter();
    }

    @Bean
    protected Step readDrivers() {
        return steps
                .get("readDrivers")
                .tasklet(driversReader())
                .build();
    }

    @Bean
    protected Step processDrivers() {
        return steps
                .get("processDrivers")
                .tasklet(driversProcessor())
                .build();
    }

    @Bean
    protected Step writeDrivers() {
        return steps
                .get("writeDrivers")
                .tasklet(driversWriter())
                .build();
    }

    @Bean
    public Job job() {
        return jobs
                .get("f1-winners-calculator-job")
                .start(readDrivers())
                .next(processDrivers())
                .next(writeDrivers())
                .build();
    }

}