package com.sky.utils;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.sky.exception.DriverException;
import com.sky.model.Driver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * @author Menaka HN
 * @apiNote Represents File Utility
 */
public class FileUtils {

    private static final Logger LOGGER = LoggerFactory.getLogger(FileUtils.class);

    private String fileName;
    private CSVReader CSVReader;
    private CSVWriter CSVWriter;
    private FileReader fileReader;
    private FileWriter fileWriter;
    private File file;

    public FileUtils(String fileName) {
        this.fileName = fileName;
    }

    public Driver readDriver() {
        try {
            if (CSVReader == null) {
                initReader();
            }
            String[] line = CSVReader.readNext();
            if (line == null) {
                return null;
            }
            return new Driver(line[0], Double.parseDouble(line[1]));
        } catch (Exception e) {
            LOGGER.error("Error while reading line in file: " + this.fileName);
            throw new DriverException("Error while reading line in file: " + this.fileName, e);
        }
    }

    public void writeDriver(Driver driver) {
        try {
            initWriter();
            String[] driverStringArray = new String[2];
            driverStringArray[0] = driver.getName();
            driverStringArray[1] = String.valueOf(driver.getAverageLapTime());
            CSVWriter.writeNext(driverStringArray);
        } catch (Exception e) {
            LOGGER.error("Error while writing line in file: " + this.fileName);
            throw new DriverException("Error while writing line in file: " + this.fileName, e);
        }
    }

    private void initReader() {
        try {
            ClassLoader classLoader = this.getClass().getClassLoader();
            if (file == null) {
                file = new File(classLoader.getResource(fileName).getFile());
            }
            if (fileReader == null) {
                fileReader = new FileReader(file);
            }
            if (CSVReader == null) {
                CSVReader = new CSVReader(fileReader);
            }
        } catch (IOException e) {
            LOGGER.error("File not found: " + fileName);
            throw new DriverException("File not found: " + fileName, e);
        }
    }

    private void initWriter() {
        try {
            if (file == null) {
                file = new File(fileName);
                file.delete();
                file.createNewFile();
            }
            if (fileWriter == null) {
                fileWriter = new FileWriter(file, true);
            }
            if (CSVWriter == null) {
                CSVWriter = new CSVWriter(fileWriter);
            }
        } catch (IOException e) {
            LOGGER.error("Error while creating output file: " + fileName);
            throw new DriverException("Error while creating output file: " + fileName, e);
        }
    }

    public void closeWriter() {
        try {
            CSVWriter.close();
            fileWriter.close();
        } catch (IOException e) {
            LOGGER.error("Error while closing writer.");
            throw new DriverException("Error while closing writer.", e);
        }
    }

    public void closeReader() {
        try {
            CSVReader.close();
            fileReader.close();
        } catch (IOException e) {
            LOGGER.error("Error while closing reader.");
            throw new DriverException("Error while closing reader.", e);
        }
    }
}