package com.sky.service;

import com.sky.model.Driver;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author Menaka HN
 * @apiNote This is the service class which is responsible for:
 * 1) Calculation of sum of lap times of each drivers
 * 2) Calculation of average of lap times of each drivers
 * 3) Sort the drivers based on average lap times.
 */

@Service
public class CalculationService {

    public List<Driver> processDrivers(final List<Driver> drivers) {
        final List<Driver> processedDrivers = calculateSumLapTime(drivers);
        calculateAverageLapTime(processedDrivers);
        sortBasedOnAverageLapTime(processedDrivers);
        return processedDrivers;
    }

    private List<Driver> calculateSumLapTime(final List<Driver> drivers) {
        Map<String, Driver> driverMap = new HashMap<>();
        drivers.stream().forEach(driver -> {
            String driverName = driver.getName();
            if (driverMap.containsKey(driverName)) {
                Driver cachedDriver = driverMap.get(driverName);
                cachedDriver.setLapCount(cachedDriver.getLapCount() + 1);
                cachedDriver.setSumLapTime(cachedDriver.getSumLapTime() + driver.getCurrentLapTime());
                driverMap.put(driverName, cachedDriver);
            } else {
                driverMap.put(driverName, driver);
            }
        });
        return new ArrayList<>(driverMap.values());
    }

    private void calculateAverageLapTime(final List<Driver> drivers) {
        drivers.stream().forEach(driver -> {
            driver.setAverageLapTime(driver.getSumLapTime() / driver.getLapCount());
        });
    }

    private void sortBasedOnAverageLapTime(final List<Driver> drivers) {
        drivers.sort(Comparator.comparing(Driver::getAverageLapTime));
    }

}
